export default interface ISubscriptions {
    subscriptions: []
};